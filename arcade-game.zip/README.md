Front End Nanodegree Arcade Game
________________________________________________________________________________________________________________________

Storyline:

The goal of the game is to fly Millennium Falcon to the space and to safety while dodging Imperial fighters. If collided
with Imperial fighters player will be reset to initial position, and accompanied with Yoda message. If player reaches
space and safety, Luke Skywalker will be shown with success message.

While Yoda and Luke Skywalker messages are present controls are disabled so player can continue after game is reset.

How to play:

To start the game please open index.html file in your browser.

Controls:

To control Millennium Falcon use your keyboard arrow keys. Up, right, down and left.

Students should use this [rubric](https://www.udacity.com/course/viewer/#!/c-nd001/l-2696458597/m-2687128535)